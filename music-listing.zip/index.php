<?php
header('Content-Type: text/html; charset=utf-8');
mb_internal_encoding('utf-8');
if(is_dir('include')) {
    if(file_exists('include/music-lister.php')) {
        include('include/music-lister.php');
    }   
    if(class_exists('MusicDirectory')) {
            $music = new MusicDirectory();  
            $music->setMusicDirectory('music-tracks');
            $music->setDatabaseDirectory('database');
            $music->setDatabaseFile('database.csv');
            $music->setFilters(array('mp3', 'MP3'));
            $music->setIgnores(array('cgi-bin', '.', '..'));
            $music->getMusicListings();
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8" />
    </head>
    <body>
        <?php
            $music->showMusicDirectory();
        ?>
    </body>
</html>